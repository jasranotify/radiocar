
</style>


<div id="templatemo_main" style="min-height:80%;">


<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Radio Amatur Registration</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Name</label>  
  <div class="col-md-4">
  <input id="textinput" name="textinput" type="text" placeholder="name" class="form-control input-md" required="">
  <span class="help-block">help</span>  
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="email">email</label>  
  <div class="col-md-4">
  <input id="email" name="email" type="text" placeholder="email" class="form-control input-md" required="">
  <span class="help-block">help</span>  
  </div>
</div>

<!-- Multiple Radios -->
<div class="form-group">
  <label class="col-md-4 control-label" for="Gender">Gender</label>
  <div class="col-md-4">
  <div class="radio">
    <label for="Gender-0">
      <input type="radio" name="Gender" id="Gender-0" value="1" checked="checked">
      Male
    </label>
	</div>
  <div class="radio">
    <label for="Gender-1">
      <input type="radio" name="Gender" id="Gender-1" value="2">
      Female
    </label>
	</div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="Ic">IC</label>  
  <div class="col-md-4">
  <input id="Ic" name="Ic" type="text" placeholder="email" class="form-control input-md" required="">
  <span class="help-block">help</span>  
  </div>
</div>

<!-- Prepended checkbox -->
<div class="form-group">
  <label class="col-md-4 control-label" for="prependedcheckbox">Prepended Checkbox</label>
  <div class="col-md-4">
    <div class="input-group">
      <span class="input-group-addon">     
          <input type="checkbox">     
      </span>
      <input id="prependedcheckbox" name="prependedcheckbox" class="form-control" type="text" placeholder="placeholder">
    </div>
    <p class="help-block">help</p>
  </div>
</div>

</fieldset>
</form>



<span class="style1">WELCOME TO Radio Amatur</span>
</div>
