<div id="templatemo_main" style="min-height:80%;">


<?php
$q="select a.password from tbl_user a where a.id='3'";
list($crypttext)=mysql_fetch_row(mysql_query($q));
$key="hadi123";


   //echo $crypttext;
?>


cerita tentang kelab ini...kalau ada video boleh attach di sini juga,gambar,event dan sebagainya
</div>
