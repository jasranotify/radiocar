<html>
<head>
	<title><?php echo $page;?></title>
	<link rel="shortcut icon" href="<?php echo $base."include/images/icon.jpg"; ?>"/>
	
	
<?php /*?>	
<link rel="stylesheet" href="<?php echo $base; ?>include/blueprint/screen.css" media="screen,projection" />
<link rel="stylesheet" href="<?php echo $base; ?>include/blueprint/print.css" media="print" />
<?php */?>

<script type="text/javascript">
    var GB_ROOT_DIR = "<?php echo $base; ?>include/greybox/";
</script>

<script type="text/javascript" src="<?php echo $base; ?>include/greybox/AJS.js"></script>
<script type="text/javascript" src="<?php echo $base; ?>include/greybox/AJS_fx.js"></script>
<script type="text/javascript" src="<?php echo $base; ?>include/greybox/gb_scripts.js"></script>
<link href="<?php echo $base; ?>include/greybox/gb_styles.css" rel="stylesheet" type="text/css" />

<?php /*?>background-image:url(<?php echo $base; ?>images/images.jpg)<?php */?>

<?php
echo "<pre>";
//print_r($_SESSION);
date_default_timezone_set ("Asia/Kuala_Lumpur");
$date=date("d/m/Y H:i:s");
echo "</pre>";

$url= $base."include/templatemo/";
?>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Radio Amatur</title>
<meta name="keywords" content="titanium, free theme, web design, templatemo 372" />
<meta name="description" content="Titanium is free web template from templatemo.com" />


<link href="<?php echo $url; ?>templatemo_style.css" rel="stylesheet" type="text/css" />



<link rel="stylesheet" type="text/css" href="<?php echo $url; ?>css/ddsmoothmenu.css" />

<script type="text/javascript" src="<?php echo $url; ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $url; ?>js/ddsmoothmenu.js">





/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>









</head>

<?php


?>