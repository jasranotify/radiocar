
<div class="span-20last">
&nbsp;
</div>
<div class="span-20">
<span style="font-size:10px; font-style:italic;">Hakcipta terpelihara.copyright by hadieh nawang.
diah@gmail.com
</span>
</div>

</div>