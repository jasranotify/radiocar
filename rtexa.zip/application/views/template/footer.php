<div id="templatemo_footer_wrapper">    
    <div id="templatemo_footer">
    	<p>Copyright �EDDY  <a href="#">myweb</a> |
        	</p>
    </div><!-- END of templatemo_footer -->
</div><!-- END of templatemo_footer_wrapper -->
</body>
</html>