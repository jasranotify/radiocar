<!DOCTYPE html>
<html>
<body>

<table width="500" border="0">
<tr>
<td colspan="5" style="background-color:#FFA500;">
<h1>SPP</h1>
<h2>Sistem Pemantauan Prestasi</h2>
</td>
</tr>

<tr>
<td style="background-color:#FFD700;width:100px;">
<b>Admin</b><br>
Auditor<br>

</td>
<td style="background-color:#eeeeee;height:200px;width:400px;">
Selamat Datang ke Sistem Pemantauan Prestasi</td>
</tr>

<tr>
<td colspan="5" style="background-color:#FFA500;text-align:center;">footer</td>
</tr>
</table>

</body>
</html>